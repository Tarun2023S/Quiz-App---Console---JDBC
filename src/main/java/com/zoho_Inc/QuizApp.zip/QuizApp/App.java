package com.zoho_Inc.QuizApp;
import java.sql.*;
import java.util.*;

public class App {
    private static String url = "jdbc:mysql://localhost:3306/";
    private static String userName = "root";
    private static String password = "root";

    private static int validChoices() {
        int choice = 0;
        Scanner sc = new Scanner(System.in);

        while (true) {
            try {
                System.out.println("\t\n*** QUIZ APP ***\n");
                System.out.println("\t1. PLAY GAME");
//                System.out.println("\t2. DISPLAY OPTIONS FOR A QUESTION");
//                System.out.println("\t3. DISPLAY ALL QUESTIONS");
                System.out.println("\t4. EXIT\n");
                System.out.print("Enter your choice: ");
                choice = sc.nextInt();
                break; 
            } catch (InputMismatchException e) {
                System.out.println("Please enter a valid integer choice.\n");
                sc.next(); 
            }
        }

        return choice;
    }

    
    public static void main(String[] args) {
//        System.out.println("Hello World!");
        try (Connection connection = DriverManager.getConnection(url, userName, password);) {
            Class.forName("com.mysql.cj.jdbc.Driver");
//            System.out.println("Connection Established successfully..");

            if (!DBManager.databaseExists(connection)) {
            	DBManager.createDatabase(connection);
            } else {
//                System.out.println("Database already exists");
            }

            // CREATE NECESSARY TABLES
            DBManager.createNecessaryTables(connection);

            // POPULATE SOME DATA
//            populateData(categoryTableName, "category", connection);
//            populateData(optionTableName, "options", connection);
//            fetchDataFromTheTables(optionTableName, connection);
//            populateData(questionTableName, "question, category_id, answer_id", connection);
//            populateData(questionOptionTableName, "question_id, options_id", connection);
//            fetchDataFromTheTables(questionOptionTableName, connection);

            // QUIZ APPLICATION MENU
            Scanner sc = new Scanner(System.in);
            GameManager gm = new GameManager();
            PersonManager pm = new PersonManager();
            while (true) {
                int choice = validChoices();
                switch (choice) {
                    case 1:
                    	System.out.println("ENTER THE PLAYER NAME.. ");
                        String personName = sc.next();
                        Person p = new Person(personName);
                        gm.playGame(connection, p);
                        break;
                    case 2:
                        System.out.print("Enter question_id to display options: ");
                        int questionId = sc.nextInt();
                        DBManager.displayOptionsForQuestion(connection, questionId);
                        break;
                    case 3:
//                    	Person p = new Person("Batista", "bat@2023", "bat@123");
//                    	gm.playGame(connection, p);
                    	DBManager.displayAllQuestions(connection);
                    	break;
                    case 4:
                        System.out.println("Exiting Quiz Application. Goodbye!");
                        System.exit(0);
                        break;
                    default:
                        System.out.println("Invalid choice. Please enter a valid option.");
                }
            }
//            if(pm.checkIfThePersonExists(personName)) {
//            	
//            }
            
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }

}