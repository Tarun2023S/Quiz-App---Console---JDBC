package com.zoho_Inc.QuizApp;
import java.sql.*;
import java.util.*;

public class GameManager {
	private String playername = "Brock Lesnar";
	static DBManager dbm;
	private static String databaseName = dbm.getDatabaseName();
	private static String optionTableName = dbm.getOptionTableName();
	private static String questionTableName = dbm.getQuestionTableName();
	private static String questionOptionsTableName = dbm.getQuestionOptionTableName();
	
	List<Person> personList;
	Map<Integer, Person> personQuizManager;
	private static class Question {
        private final int id;
        private final String questionText;
        private final int categoryId;
        private final int answerId;

        public Question(int id, String questionText, int categoryId, int answerId) {
            this.id = id;
            this.questionText = questionText;
            this.categoryId = categoryId;
            this.answerId = answerId;
        }

        public int getId() {
            return id;
        }

        public String getQuestionText() {
            return questionText;
        }

        public int getCategoryId() {
            return categoryId;
        }

        public int getAnswerId() {
            return answerId;
        }
        
        public String toString() {
        	return "id: "+id+"\nquestionText: "+questionText+"\ncategory: "+categoryId+"\nanswerId: "+answerId;
        }
    }
	public GameManager() {
		dbm = new DBManager();
		personQuizManager = new HashMap();
		personList = new LinkedList();
	}
	void playGame(Connection connection, Person p) {
		try {
			int randomFetchNumber = 2;
			List <Question> questionList = fetchRandomQuestions(connection, databaseName, questionTableName, randomFetchNumber);
//			System.out.println(p);
			
			for(int i=0;i<questionList.size();i++) {
				displayQuestionOptions(questionList.get(i), connection, p, i+1);
			}
			int totalMatchesCount = p.getTotalQuizTaken();
			p.setTotalQuizTaken(totalMatchesCount+1);
//			System.out.println(p);
			System.out.println("\t**GAME OVER**\n");
			float fractionScore = 100/randomFetchNumber;
			float percentageScore = fractionScore * p.getTotalWins();
	
			System.out.println("YOUR SCORE IS: "+p.getTotalWins()+" / "+randomFetchNumber+" ("+percentageScore+" %)");
		} catch (SQLException e) {
			e.printStackTrace();
		} catch(Exception e) {
			System.out.println("Eror occurred: "+e.getMessage());
		}
	}
	
	// Method to fetch four random questions
    private static List<Question> fetchRandomQuestions(Connection connection, String databaseName, String questionTableName, int count) throws SQLException {
        List<Question> questions = new ArrayList<>();
        String fetchDataQuery = "SELECT * FROM " + databaseName + "." + questionTableName + " ORDER BY RAND() LIMIT ?";
        try (PreparedStatement ps1 = connection.prepareStatement(fetchDataQuery)) {
            ps1.setInt(1, count);
            ResultSet resultSet = ps1.executeQuery();

            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String questionText = resultSet.getString("question");
                int categoryId = resultSet.getInt("category_id");
                int answerId = resultSet.getInt("answer_id");
                Question question = new Question(id, questionText, categoryId, answerId);
                questions.add(question);
            }
        }
        return questions;
    }

    // Method to display options for a question
    private static void displayQuestionOptions(Question question, Connection connection, Person p, int questionNumber) throws SQLException {
        String fetchDataQuery = "SELECT op.id, op.options FROM " + databaseName + "." + questionOptionsTableName + " qo JOIN "+databaseName+"."+optionTableName+" op ON qo.options_id = op.id WHERE qo.question_id = ? ";
        fetchDataQuery += "ORDER BY RAND();";

        try (PreparedStatement ps1 = connection.prepareStatement(fetchDataQuery)) {
            ps1.setInt(1, question.getId());
            ResultSet resultSet = ps1.executeQuery();
            Map<Character, Integer> optionChoiceMap = new HashMap();
            char optionChoice = 'a';
            System.out.println("\nQUESTION "+questionNumber+":    "+question.getQuestionText()+"\n");
            while (resultSet.next()) {
                int optionId = resultSet.getInt("op.id");
                String optionText = resultSet.getString("options");
                System.out.print(optionChoice + ". " + optionText+"\t");
                optionChoiceMap.put(optionChoice, optionId);
                optionChoice += 1;
            }
            Scanner sc = new Scanner(System.in);
            System.out.println();
            System.out.println("\nEnter your choice..");
            char choice = sc.next().charAt(0);
            
        	int totalWins = p.getTotalWins();
        	int totalLosses = p.getTotalLosses();
            if(validateAnswer(question, choice, connection, optionChoiceMap)) {
            	System.out.println("Its an correct answer..");
            	if(p.getTotalQuizTaken()==0) {
            		p.setTotalWins(1);
            		p.setTotalQuizTaken(1);
            	} else {
            		p.setTotalWins(totalWins + 1);
            	}
            }
            else {
            	System.out.println("WRONG ANSWER..");
            	String correctAnswer = getOptionNameById(question.answerId, connection);
            	System.out.println("THE CORRECT ANSWER IS: "+correctAnswer);
            	if(p.getTotalQuizTaken()==0) {
            		p.setTotalLosses(1);
            		p.setTotalQuizTaken(1);
            	} else {
            		p.setTotalLosses(totalLosses + 1);
            	}
            }
        }
    }

//    // Method to validate the user's answer
    private static boolean validateAnswer(Question question, char userChoice, Connection connection, Map<Character, Integer> optionChoiceMap) throws SQLException {
    	int actualChoice = optionChoiceMap.get(userChoice);
        String fetchDataQuery = "SELECT * FROM " + databaseName + "." + questionTableName + " WHERE id = ? AND answer_id = ?;";
//        System.out.println("Fetch Querry Data: "+fetchDataQuery+question.getAnswerId()+", "+userChoice);
        try (PreparedStatement ps1 = connection.prepareStatement(fetchDataQuery)) {
            ps1.setInt(1, question.getId());
            ps1.setInt(2, actualChoice);
            ResultSet resultSet = ps1.executeQuery();
//            System.out.println("Quest: "+question);
            return resultSet.next(); 
        }
    }
    
    private static String getOptionNameById(int options_id, Connection connection) {
    	String query = "SELECT options FROM " + databaseName + "." +optionTableName+" WHERE id = ?;";
    	try(PreparedStatement ps = connection.prepareStatement(query);) {
    		ps.setInt(1, options_id);
    		ResultSet resultSet = ps.executeQuery();
    		resultSet.next();
    		return resultSet.getString("options");
    	}
    	catch(Exception e) {
    		System.out.println("An Error occurred.."+e.getMessage());
    	}
    	return "";
    }
    
    private static int validChoices() {
        char choice = 'a';
        Scanner sc = new Scanner(System.in);

        while (true) {
            try {
                System.out.print("Enter your choice: ");
                choice = sc.next().charAt(0);
                break; 
            } catch (InputMismatchException e) {
                System.out.println("PLEASE ENTER AN VALID OPTION CHOICE..\n");
                sc.next(); 
            }
        }

        return choice;
    }
}
